#pragma once
#include "Database.h"
#include "DataLogProgram.h"


class Interpreter {
    private:
        DataLogProgram interpDatalog;
    	Database database;
    public:
        Interpreter(DataLogProgram datalog);
        void makeDataBase();
	int getDatabaseCount();
	void evaluateQuery(Predicate query);
	Relation evaluatePredicate(Predicate bodyPred);
    	void evaluateAllQueries();
	Relation evaluateRule(Rule rule);
    	void evaluateRules();
};
